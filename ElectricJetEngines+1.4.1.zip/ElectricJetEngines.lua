-- Electric Jet Engines
-- Converts the Wheesley, Whittle, and Goliath turbofans to running on ElectricCharge instead of fuel. Optionally rebalances the tech tree.
-- Config

local enableWheesley = Config:Bool("Engines", "Wheesley Electric",    true, "Restart required to apply changes.")
local enableWhittle  = Config:Bool("Engines", "Whittle Electric",     true, "Restart required to apply changes.")
local enableGoliath  = Config:Bool("Engines", "Goliath Electric",     true, "Restart required to apply changes.")
local enableTechTree = Config:Bool("TechTree", "Rebalance Tech Tree", true, "Restart required to apply changes.")

-- Electric propellant recipe 

PM.Resources:NewRecipe("ElectricJetPropellant", function(recipe)
    recipe.displayNameKey  = "Resource/DisplayName/ElectricCharge"
    recipe.abbreviationKey = "Resource/Abbreviation/EC"
    recipe.vfxFuelType     = "Electric"
    recipe.ingredients:Add("ElectricCharge", 50000.0)
end)

-- swap propellant on all engine modes and removes fuel containers 

local function electrifyEngine(part)
    part:PatchModule("Module_Engine", function(module)
        module:PatchData("Data_Engine", function(engine)
            for _, mode in pairs(engine.engineModes) do
                mode.propellant.mixtureName = "ElectricJetPropellant"
            end
        end)
    end)
    part.resourceContainers:RemoveWhere(function(c)
        return c.name == "MethaneAir"
            or c.name == "Methane"
            or c.name == "LiquidFuel"
    end)
end

-- Part patches 

PM.Parts:Patch("ElectricWheesley")
    :Named("engine_1v_turbofan_methane_wheesley")
    :Requires(enableWheesley, "Wheesley electric conversion is disabled.")
    :Do(function(part) electrifyEngine(part) end)

PM.Parts:Patch("ElectricWhittle")
    :Named("engine_0v_methane_whittle")
    :Requires(enableWhittle, "Whittle electric conversion is disabled.")
    :Do(function(part) electrifyEngine(part) end)

PM.Parts:Patch("ElectricGoliath")
    :Named("engine_2v_turbofan_methane_goliath")
    :Requires(enableGoliath, "Goliath electric conversion is disabled.")
    :Do(function(part) electrifyEngine(part) end)

-- Tech tree rebalance

PM.Science:PatchTechNodes("ElectricEnginesTechTree")
    :Requires(enableTechTree, "Tech tree rebalance is disabled.")
    :Do(function(node)

        if node.ID == "tNode_1v_aero_02" then
            node.UnlockedPartsIDs:Clear()
            node.UnlockedPartsIDs:Append("cockpit_1v_m1_crew")
            node.UnlockedPartsIDs:Append("cockpit_1v_m1_inline_crew")
            node.UnlockedPartsIDs:Append("fueltank_1v_m1_inline_methane")
            node.UnlockedPartsIDs:Append("engine_1v_turbofan_methane_wheesley")
            node.UnlockedPartsIDs:Append("engine_1v_turbofan_methane_panther")
            node.UnlockedPartsIDs:Append("landinggear_1v")
            node.UnlockedPartsIDs:Append("landinggear_1v_fixed")
            node.UnlockedPartsIDs:Append("intake_1v_circular")
            node.UnlockedPartsIDs:Append("wing_1v_procedural_light")
            node.UnlockedPartsIDs:Append("stabilizer_2v_procedural_heavy")
            node.UnlockedPartsIDs:Append("storage_1v_battery_electricity")
        end

        if node.ID == "tNode_2v_electronics_01" then
            node.UnlockedPartsIDs:Clear()
            node.UnlockedPartsIDs:Append("solararray_2v_accordion")
            node.UnlockedPartsIDs:Append("fuelcell_0v")
        end

        if node.ID == "tNode_2v_aero_01" then
            node.UnlockedPartsIDs:Clear()
            node.UnlockedPartsIDs:Append("cockpit_2v_m2_crew")
            node.UnlockedPartsIDs:Append("cockpit_2v_m2_inline_crew")
            node.UnlockedPartsIDs:Append("landinggear_2v")
            node.UnlockedPartsIDs:Append("airbrake_1v")
            node.UnlockedPartsIDs:Append("intake_1v_m1_nacelle_methane")
            node.UnlockedPartsIDs:Append("fueltank_2v_m2_inline_methane_1x1")
            node.UnlockedPartsIDs:Append("fueltank_2v_m2_inline_methane_1x2")
            node.UnlockedPartsIDs:Append("wing_2v_procedural_heavy")
        end

    end)
